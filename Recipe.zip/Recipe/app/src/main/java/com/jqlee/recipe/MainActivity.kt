package com.jqlee.recipe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinner = findViewById<Spinner>(R.id.categorySpinner)

        setupSpinner(spinner)

        val text = findViewById<TextView>(R.id.tvText)
        val btnAdd = findViewById<FloatingActionButton>(R.id.addbtn)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                text.text = Categories.categories[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                text.text = Categories.categories[0]
            }
        }

        btnAdd.setOnClickListener{
            val i = Intent(this, AddRecipeActivity::class.java)
            startActivity(i)
        }
    }

    private fun setupSpinner(spin: Spinner){
        val adapter = CategoryArrayAdapter(this, Categories.list!!)
        spin.adapter = adapter
    }
}